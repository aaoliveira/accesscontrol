<?php
/**
 * Component AccessControl
 * For CakePHP 2.x
 * Autor: Ribamar FS
 *
 * This component allow access control to each action from application with web interface.
 *
 * Licenced with The MIT License
 * Redistributions require keep copyright below.
 *
 * @copyright     Copyright (c) Ribamar FS (http://ribafs.org)
 * @link          http://ribafs.org
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Component', 'Controller');

class AccessControlComponent extends Component{
	public $uses = array('Privilege');
	public $components = array('Session','Auth');
	public $redir=false;

	public function startup(Controller $controller) {
		$this->Controller = $controller;
	}

	public function admin() {
		$value = $this->Session->read('Auth.User');  //Return array with user id and name
		$groupauth=$value['Group']['name'];
		if(isset($groupauth) && $groupauth == 'admins'){
			return true;
		}else{
			return false;
		}
	}	

	public function adminAccess() {
		if(!$this->admin()){
			$this->Session->setFlash(__('Acess Denied!'));
			$this->redir = true;
			return $this->redir;
		}
	}

	public function manager() {
		$value = $this->Session->read('Auth.User');
		$groupauth=$value['Group']['name'];
		if((isset($groupauth) && $groupauth == 'managers') || $groupauth == 'admins')	{
			return true;
		}else{
			return false;
		}
	}	

	public function managerAccess() {
		if(!$this->manager()){
			$this->Session->setFlash(__('Access Denied!'));
			$this->redir = true;
			return $this->redir;
		}
	}

	public function user() {
		$valor = $this->Session->read('Auth.User');
		$groupauth=$valor['Group']['name'];
		if((isset($groupauth) && $groupauth == 'users') || $groupauth == 'managers' || $groupauth == 'admins')	{
			return true;
		}else{
			return false;
		}
	}	

	public function userAccess() {
		if(!$this->user()){
			$this->Session->setFlash(__('Access Denied!'));
			$this->redir = true;
			return $this->redir;
		}
	}

	public function access($controller,$action){
		$this->Privilege = ClassRegistry::init('Privilege');// Allow model use in component
		$this->Group = ClassRegistry::init('Group');

		$group = $this->Privilege->find('first', array(
	            'conditions'=>array('Privilege.controller'=>$controller,'Privilege.action'=>$action),
	            'fields'=>array('Privilege.group_name')
	        ));

		if(isset($group['Privilege']['group_name'])){
			$group = $group['Privilege']['group_name'];
			return $group;
		}else{
			return false;	
		}
	}

	public function go($controller,$action){
		if($this->access($controller,$action) == 'admins') {
			$this->adminAccess();
		}elseif($this->access($controller,$action) == 'managers'){
			$this->managerAccess();
		}elseif($this->access($controller,$action) == 'users'){	
			$this->userAccess();
		}elseif($this->access($controller,$action)==false){
			$this->Session->setFlash(__('Access Denied!'));
			return $this->redir;
		}
		// On appear Access Denied and still action accessing then this privilege is not registered.
	}
}
